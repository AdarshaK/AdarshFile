//
//  CellIdTableViewCell.m
//  immi
//
//  Created by Ravi on 30/11/16.
//  Copyright © 2016 ABI. All rights reserved.
//

#import "CellIdTableViewCell.h"

@implementation CellIdTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
