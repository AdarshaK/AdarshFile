//
//  splViewController.h
//  immi
//
//  Created by Ravi on 19/12/16.
//  Copyright © 2016 ABI. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface splViewController : UIViewController

@end
