//
//  AppDelegate.h
//  immi
//
//  Created by Ravi on 29/11/16.
//  Copyright (c) 2016 ABI. All rights reserved.
//

#import <UIKit/UIKit.h>
@class RegisterViewController;
@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong,nonatomic) RegisterViewController *registe;

@end

